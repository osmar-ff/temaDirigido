This is the RFremote library for the Arduino.

To download from github (https://github.com/renatoaloi/RFremote), click on the "Downloads" link in the upper right, click "Download as zip", and get a zip file.  Unzip it and rename the directory RFremote

To install, move the downloaded RFremote directory to:
My Documents/Arduino/libraries/RFremote
where My Documents/Arduino is your Arduino sketches directory

After installation you should have files such as:
My Documents/Arduino/libraries/RFremote/RFremote.cpp

For details on the library see the Wiki on github

Copyright 2013 Renato Aloi
